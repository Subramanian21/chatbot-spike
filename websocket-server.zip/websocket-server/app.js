const axios = require('axios')
const jwt = require('jsonwebtoken');
const express = require('express');
const app = express();
const httpServer = require('http').createServer(app);
const io = require("socket.io")(httpServer, {
    cors: {
        origin: "*",
        methods: ["GET", "POST"]
    },
    transports: ['websocket']
});

function publishMessage(senderId, message) {
    axios
        .post('http://localhost:3100/api/sendMsg', {
            senderId: senderId,
            message: message
        }, {
            headers: {
                'cora-channel': 'web'
            }
        })
        .then(res => {
            console.log('status code: '+ res.status + ', data: '+ JSON.stringify(res.data))
        })
        .catch(error => {
            console.error(error)
        })
}

const setDisconnectTimeout = (socket) => {
    socket.disconnectTimeout = setTimeout(() => {
        // token is not sent from the user within x seconds
        console.log("Client does not re-auth within the specific time, disconnect")
        socket.disconnect(true);
    }, 1 * 60 * 1000);
}

const setAuthExpireTimeout = (socket, tokenExpireIn) => {
    socket.authExpireTimeout = setTimeout(() => {
        console.log("Last submitted token expired, need to reauth")
        // rquest the user to reauthenticate
        socket.emit('token_reauth');
        // set the logoutTimeout, if client don't provide new jwt, disconnect
        setDisconnectTimeout(socket);
    }, tokenExpireIn);
}

io.on('connection', (socket) => {
    console.log('New socket connected ' + socket.id);

    socket.on('authenticate', (data) => {
        // validtate the token from client and set the decoded token in the socket
        jwt.verify(data.token, 'passw0rd', function (err, decoded) {
            if (err) {
                console.log("Invalid token");
                io.to(socket.id).emit('token_error', err);
            } else {
                console.log('decoded token' + JSON.stringify(decoded));
                socket.decoded_token = decoded;

                // if the user re-authenticate successfully, don't disconnect
                if(socket.disconnectTimeout) {
                    clearTimeout(socket.disconnectTimeout);
                }

                // create new reauthTimeout
                const tokenExpireIn = decoded.exp * 1000 - Date.now();
                console.log('token will expire in ', (tokenExpireIn / 1000) + ' seconds');
                socket.authExpireTimeout = setAuthExpireTimeout(socket, tokenExpireIn);
            }
        });
    });

    socket.on('newMessage', (data) => {
        publishMessage(socket.id, data.message)
    });

    // Disconnect Event Handler
    socket.on('disconnect', () => {
        console.log('user disconnected ' + socket.id);
    });

    socket.on('channelResponse', (message) => {
        var msg = JSON.parse(message);
        console.log(msg)
        if (msg && msg.senderId) {
            io.to(msg.senderId).emit('respondMessage', msg.message);
        }
    });
});

httpServer.listen(3000, () => {
    console.log('Websocket Server listening on port 3000');
});