const express = require('express');
const app = express();
const httpServer = require('http').createServer(app);
const io = require("socket.io")(httpServer, {
    cors: {
        origin: "*",
        methods: ["GET", "POST"]
    },
    transports: ['websocket']
});

httpServer.listen(3000, () => {
    console.log('Websocket Server listening on port 3000');
});

io.on('connection', (socket) => {
    console.log('New socket connected ' + socket.id);

    // Disconnect Event Handler
    socket.on('disconnect', () => {
        console.log('user disconnected ' + socket.id);
    });

    socket.on('channelResponse', (message) => {
        var msg = JSON.parse(message);
        console.log(msg)
        if (msg && msg.senderId) {
            io.to(msg.senderId).emit('respondMessage', msg.message);
        }
    });
});