const axios = require('axios')
const { Kafka, logLevel, AssignerProtocol: {MemberAssignment, MemberMetadata}, PartitionAssigners: { roundRobin }} = require('kafkajs')
const kafka_input_topic = 'cora-input-topic'
const web_partitions = [0, 1, 2]
const partitionAssigner = require('./partitionAssigner')
const kafka = new Kafka({
    logLevel: logLevel.INFO,
    clientId: 'cora-app',
    brokers: ['localhost:9092']
})

const consumer = kafka.consumer({
    groupId: 'cora-input-web-consumer',
    partitionAssigners: [
        partitionAssigner.assign('InputWebPartitionAssigner', web_partitions),
        roundRobin
    ]
})

const run = async () => {
    await consumer.connect()
    await consumer.subscribe({ topic: kafka_input_topic })
    await consumer.run({
        eachMessage: async ({ topic, partition, message }) => {
            console.log({
                key: message.key.toString(),
                value: message.value.toString(),
                headers: message.headers,
            })
            var msg = JSON.parse(message.value.toString());
            if (msg && msg.senderId) {
                publishMessage(msg.senderId, "Response message from web bot")
            }
        },
    })
}

function publishMessage(senderId, message) {
    axios
        .post('http://localhost:3100/api/receiveMsg', {
            senderId: senderId,
            message: message
        }, {
            headers: {
                'cora-channel': 'web'
            }
        })
        .then(res => {
            console.log(res)
        })
        .catch(error => {
            console.error(error)
        })
}

// Start Kafka Consumer
run().catch(e => console.log(`Error starting consumer ${e.stack}`))