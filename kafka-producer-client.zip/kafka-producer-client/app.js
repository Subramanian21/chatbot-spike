const express = require('express')
var cors = require('cors')
const app = express()
const httpServer = require('http').createServer(app);
const bodyParser = require('body-parser');
const kafkaInputProducer = require('./inputProducer')
const kafkaOutputProducer = require('./outputProducer')

app.use(bodyParser.urlencoded({
    extended: false
}));
app.use(bodyParser.json());
app.use(cors())

// Start Kafka Producer
kafkaInputProducer.run().catch(e => run().catch(e => console.log(`Error starting input producer ${e.message}`)))
kafkaOutputProducer.run().catch(e => run().catch(e => console.log(`Error starting output producer ${e.message}`)))

// Endpoint to publish input message to Kafka
app.post('/api/sendMsg', async function (req, res) {
    var channel = req.header('cora-channel');
    var message = JSON.stringify(req.body);
    var msg = JSON.parse(message);
    const key = channel + '-' + msg.senderId

    var response = await kafkaInputProducer.sendMessage(key, message)
    res.json(response)
});

app.post('/api/receiveMsg', async function (req, res) {
    var channel = req.header('cora-channel');
    var message = JSON.stringify(req.body);
    var msg = JSON.parse(message);
    const key = channel + '-' + msg.senderId

    var response = await kafkaOutputProducer.sendMessage(key, message)
    res.json(response)
});

httpServer.listen(3100, () => {
    console.log('Kafka Client Server listening on port 3100');
});