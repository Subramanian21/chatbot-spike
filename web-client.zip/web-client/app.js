var express = require('express');
var app = express();
var http = require('http').createServer(app);

app.use(express.static(__dirname + '/static'));

app.get('/index', (req, res) => {
    res.sendFile(__dirname + '/static/index.html');
});

http.listen(9090, () => {
    console.log('web client started on port 9090');
});
